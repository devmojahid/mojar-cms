<?php
/**
 * JUZAWEB CMS - The Best CMS for Laravel Project
 *
 * @package    juzaweb/cms
 * @author     The Anh Dang <dangtheanh16@gmail.com>
 * @link       https://juzaweb.com/cms
 * @license    MIT
 */

namespace Mojahid\Lms\Repositories;

use Juzaweb\Backend\Repositories\PostRepository;

interface CourseRepository extends PostRepository
{
    //
}
