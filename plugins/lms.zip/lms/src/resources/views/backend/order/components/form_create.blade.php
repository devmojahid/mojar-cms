<div class="row">
    <div class="col-md-8">
        {{ Field::text($model, 'code') }}

        {{ Field::text($model, 'notes') }}
    </div>
</div>