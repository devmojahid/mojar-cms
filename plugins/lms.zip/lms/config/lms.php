<?php

return [
    'lesson_types' => [
        'video' => 'Video',
        'audio' => 'Audio',
        'document' => 'Document',
        'link' => 'Link',
    ],
];
